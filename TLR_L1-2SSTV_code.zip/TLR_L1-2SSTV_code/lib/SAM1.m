function  MSAM=SAM1(OriData3,output_image)
  if eq(size(OriData3),size(output_image))&eq(3,ndims(OriData3))
      [M,N,P]=size(OriData3);
       SAM=zeros(M,N);
      for i=1:M
          for j=1:N
               temp_true=reshape(OriData3(i,j,:),1,P);
               temp_pred=reshape(output_image(i,j,:),1,P);
               SAM(i,j)=acos(temp_true*temp_pred'/norm(temp_true)/norm(temp_pred));
          end
      end
      MSAM=mean(mean(SAM))*180/pi;
  
  end
end
  