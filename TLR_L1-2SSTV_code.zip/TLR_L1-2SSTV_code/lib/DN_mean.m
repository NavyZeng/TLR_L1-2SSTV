%load('output_image.mat')
% a=inversemap(OriData3,ori_urban);
% b=inversemap(output_image,ori_urban);
a=OriData3;
b=output_image;
% hold on;
%[x y]=find(ori_urban(:,:,1)==max(max(ori_urban(:,:,1))));
p=size(b,2);
a220=a(:,:,220);
a=zeros(1,p);
for i=1:1:p
    a(i)=mean(a220(i,:));
end
b220=b(:,:,220);
b=zeros(1,p);
for i=1:1:p
    b(i)=mean(b220(i,:));
end

subplot(121);plot(a);xlabel('Band number');
ylabel('DN'); 
subplot(122);plot(b);xlabel('Band number');
ylabel('DN'); 


% subplot(121);plot(reshape(a(112,177,:),1,210));xlabel('Band number');
% ylabel('DN'); 
% subplot(122);plot(reshape(b(112,177,:),1,210));xlabel('Band number');
% ylabel('DN'); 