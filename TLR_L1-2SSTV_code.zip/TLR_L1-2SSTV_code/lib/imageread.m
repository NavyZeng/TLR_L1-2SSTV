filename = 'noise';
[ image ] = f_read( filename);

