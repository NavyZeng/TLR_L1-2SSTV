function ff=tensor3Fro(u)
ff=sum(sum(sum(u.^2)));
ff=sqrt(ff);
return;