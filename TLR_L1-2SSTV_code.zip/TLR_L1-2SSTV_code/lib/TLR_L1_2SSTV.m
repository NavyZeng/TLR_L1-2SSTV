function [ output_image] = TLR_L1_2SSTV(oriData3_noise, par)
%% Call parameters 
blocksize = par.blocksize;
stepsize  = par.stepsize;
lambda    = par.lambda;
tau       = par.tau;
r         = par.r;
maxIter   = par.maxIter;
tol       = par.tol;
%%
[M, N, p] = size(oriData3_noise);
R         =   M-blocksize+1;
C         =   N-blocksize+1;
rr        =   [1:stepsize:R];
% rr        =   [rr rr(end)+1:R];
if rr(end)<R;rr = [rr R];else end;
cc        =   [1:stepsize:C];
% cc        =   [cc cc(end)+1:C];
if cc(end)<R;cc = [cc C];else end;
row       =   length(rr);
column    =   length(cc);
% Index image
Idxx     =   (1:row*column);
Idxx     =   reshape(Idxx, row, column);

par.rr   = rr;
par.cc   = cc;
par.row  = row;
par.column = column;
par.Idxx   = Idxx;
par.imagesize = [M,N,p];
%% Initializing optimization variables
Op = cube2patch(oriData3_noise,par); % store 3-D image patch by patch
weight = calweight(par);
[M1,N1,p1] = size(Op);
Lp = randn(M1,N1,p1);
Jp = Lp;
Sp = zeros(M1,N1,p1);
X = patch2cube(Jp,par);
YO = zeros(M1,N1,p1);
YL = zeros(M1,N1,p1);
YX = zeros(M,N,p);
H =1;
beta = [1 1 0.5];
%%
rho = 1.5;
max_mu1 = 1e6;
% mu = 1e-2;
mu= 1e-3;
% mu = 0.24;
% mu = 0.15;
% mu = 1e-3;
% sv =10;
%%
%% main loop
iter = 0;
while iter<maxIter
    iter = iter + 1;
    %    Update L & Lp
    Lp  = Lp_solver(Op , Sp , Jp, YO, YL, mu,par,p); % Tensor SVT for TNN
    %    Update S & Sp
    temp_S = Op - Lp+ YO/mu;
    Sp_hat = max(temp_S - lambda/mu, 0);
    Sp = Sp_hat+min(temp_S + lambda/mu, 0);
    %    Update J & Jp
    temp_C = Lp + YL/mu;
    temp_D = X - YX/mu;
    J      = update_J(temp_C,temp_D,weight,par);
    Jp     = cube2patch(J,par);
    %    Update X
    temp = J + YX/mu;
    Htg  = imfilter(temp, H, 'circular');
    lambda1=mu/tau;
    pm.muu=5.5;
    X =DCA_for_L1_2SSTV(Htg,0.2, pm,lambda1);% DCA for L1-2SSTV
    leq1 = Op - Lp - Sp;
    leq2 = Lp - Jp;
    leq3 = J - X;
    %% stop criterion
    stopC1 = max(abs(leq1(:)));
    stopC2 = max(abs(leq2(:)));
    stopC3 = max(abs(leq3(:)));
    stopC = max(max(stopC1,stopC2),stopC3);
    if stopC<tol
        break;
    else
        YO = YO + mu*leq1;
        YL = YL + mu*leq2;
        YX = YX + mu*leq3;
        mu = min(max_mu1,mu*rho);
    end
        output_image = J;  
end
    function d = Dx(X)
        [rows,cols,pages] = size(X);
        d = zeros(rows,cols,pages);
        d(:,2:cols,pages) = X(:,2:cols,pages)-X(:,1:cols-1,pages);
        d(:,1,pages) = X(:,1,pages)-X(:,cols,pages);
    end

    function d = Dxt(X)
        [rows,cols,pages] = size(X);
        d = zeros(rows,cols,pages);
        d(:,1:cols-1,pages) = X(:,1:cols-1,pages)-X(:,2:cols,pages);
        d(:,cols,pages) = X(:,cols,pages)-X(:,1,pages);
    end

    function d = Dy(X)
        [rows,cols,pages] = size(X);
        d = zeros(rows,cols,pages);
        d(2:rows,:,pages) = X(2:rows,:,pages)-X(1:rows-1,:,pages);
        d(1,:,pages) = X(1,:,pages)-X(rows,:,pages);
    end

    function d = Dyt(X)
        [rows,cols,pages] = size(X);
        d = zeros(rows,cols,pages);
        d(1:rows-1,:,pages) = X(1:rows-1,:,pages)-X(2:rows,:,pages);
        d(rows,:,pages) = X(rows,:,pages)-X(1,:,pages);
    end


    function d = Dz(X)
        [rows,cols,pages] = size(X);
        d = zeros(rows,cols,pages);
        d(:,:,1:pages-1) = X(:,:,2:pages)-X(:,:,1:pages-1);
        d(:,:,pages) = X(:,:,1)-X(:,:,pages);
    end


    function d = Dzt(X)
        [rows,cols,pages] = size(X);
        d = zeros(rows,cols,pages);
        d(:,:,2:pages) =-diff(X,1,3);
        d(:,:,pages) = X(:,:,pages)-X(:,:,1);
    end



    function [xs,ys,zs] = shrink2(x,y,z,lambda1)
        
        s = sqrt(x.*conj(x)+y.*conj(y)+z.*conj(z));
        ss = s-lambda1;
        ss = ss.*(ss>0);
        
        s = s+(s<lambda1);
        ss = ss./s;
        
        xs = ss.*x;
        ys = ss.*y;
        zs = ss.*z;
    end


    function z = shrink(x,r)
        z = sign(x).*max(abs(x)-r,0);
    end


    function [D,Dt] = defDDt(beta)
        D  = @(U) ForwardD(U, beta);
        Dt = @(X,Y,Z) Dive(X,Y,Z, beta);
    end

    function [Dux,Duy,Duz] = ForwardD(U, beta)
        frames = size(U, 3);
        Dux = beta(1)*[diff(U,1,2), U(:,1,:) - U(:,end,:)];
        Duy = beta(2)*[diff(U,1,1); U(1,:,:) - U(end,:,:)];
        Duz(:,:,1:frames-1) = beta(3)*diff(U,1,3);
        Duz(:,:,frames)     = beta(3)*(U(:,:,1) - U(:,:,end));
    end

    function DtXYZ = Dive(X,Y,Z, beta)
        frames = size(X, 3);
        DtXYZ = [X(:,end,:) - X(:, 1,:), -diff(X,1,2)];
        DtXYZ = beta(1)*DtXYZ + beta(2)*[Y(end,:,:) - Y(1, :,:); -diff(Y,1,1)];
        Tmp(:,:,1) = Z(:,:,end) - Z(:,:,1);
        Tmp(:,:,2:frames) = -diff(Z,1,3);
        DtXYZ = DtXYZ + beta(3)*Tmp;
    end
    function [ weight] = calweight(par )        
%%
        % [M1 N1 p1] = size(outpatch);
        blocksize  = par.blocksize;
        imagesize  = par.imagesize;
        
        rr        = par.rr;
        cc        = par.cc;
        row       = par.row;
        column    = par.column;
        Idxx      = par.Idxx;
        Numofpatch= row * column;
        
        weight   = zeros(imagesize);
        for idx = 1:Numofpatch
            [rowidx,columnidx] = find(Idxx==idx); % find the location in index image
            i = rr(rowidx); j = cc(columnidx);    % find the location in original image
            weight(i:i+blocksize-1,j:j+blocksize-1,:)= weight(i:i+blocksize-1,j:j+blocksize-1,:)+ 1;
        end
    end
end
