% Solve the proposed TLR_L1-2SSTV problem
% -------------------------------------------------------------------------------------------------------------
% Reference paper: ��Hyperspectral Image Restoration via Global L1?2 Spatial-Spectral Total Variation Regularized Local Low-Rank Tensor Recovery��
% Author: Haijin Zeng
% E-mail addresses:(zeng_navy@163.com)
% Note: the parameters in this section only apply to Noise Case: P=0.05, G=0.025
clc;clear;close all;
addpath(genpath('lib'));
addpath(genpath('prox_operators'));
addpath(genpath('PROPACK'));
                      
dataname = 'WashingtonDC';%% WDC 
% dataname = 'Pavia_80';               %% Pavia 
% dataname = 'simu_indian';               %% simu_indian
% dataname = 'Indian_OriData3';        %% real data: indian pines
% dataname = 'urban';                    %% real data: urban
dataRoad = ['data/' dataname];
saveroad = ['result'];

if isempty(gcp)
    parpool(4,'IdleTimeout', inf); % If your computer's memory is less than 8G, do not use more than 4 workers.
end 
%% Set enable bits
memorySaving = 1;  
% Setting 'memorySaving = 0' : parall + no memory savings
% Setting 'memorySaving = 1' : light parall + memory savings
disp( '=== Performing HSI denoising algorithm===');
EN_BWKSVD   = 0;  % set to 0 for turning off;
EN_BWBM3D   = 0;
EN_KSVD     = 0;
EN_NLM3D    = 0;
EN_LRTA     = 0;
EN_PARAFAC  = 0;
EN_Trace_TV =0;
EN_LRTV  = 0;
EN_TDL      = 0;
EN_BM4D     = 0;
EN_tSVD     = 0;
EN_KBRreg   = 0;
EN_NAILRMA  = 0;
EN_LRMR     = 0;
EN_ITSReg   = 0;
EN_LRTDTV   = 0;
EN_LLRSSTV  = 0;
EN_TLR_L1_2SSTV=1;
getGif      = 0; % if save gif result or not
getImage    = 0; % if save the appointed band of the reconstructed HSI as image result or not
mkdir(saveroad);
% rng(1);
rng('default');
%% initial Data
methodname ={'Nosiy','TLR_L1_2SSTV'};
Mnum   = length(methodname);
load(dataRoad); % load data
% OriData3= urban;% urban only
% OriData3= simu_indian;% simu_indian only
Omsi    = OriData3;% varibity change
Omsi    = normalized(Omsi);
msi_sz  =  size(Omsi);
band    = 1; %the band to show and save
temp    = Omsi(:,:,band);
maxI    = max(temp(:));
minI    = min(temp(:));
[M,N,p] = size(Omsi);
noisy_msi = zeros(M,N,p);
%% add noise
sigma_ratio = 0.025;    % higher sigma_ratio <--> heavier Gaussian noise
s_ratio=0.05;           % higher s_ratio<--> heavier S&P noise  
ratio = s_ratio*ones(1,p);            % S&P noise for case 1
noiselevel = sigma_ratio*ones(1,p);      % Gaussian noise for case 1
%% Gaussian noise
for i =1:p
     noisy_msi(:,:,i)=Omsi(:,:,i)  + noiselevel(i)*randn(M,N);
end
% Gaussian_noise=noisy_msi-Omsi;
%% S&P noise
for i =1:p
     noisy_msi(:,:,i)=imnoise(noisy_msi(:,:,i),'salt & pepper',ratio(i));
end
% SP_noise=noisy_msi-Omsi-Gaussian_noise;
i  = 1;
Re_msi{i} = noisy_msi;
[psnr(i), ssim(i), fsim(i)] = MSIQA(Omsi * 255, Re_msi{i}  * 255);
enList = 1;
%% TLR_L1-2SSTV
i = i+1;
if  EN_TLR_L1_2SSTV
    disp(['performing ',methodname{i}, ' ... ']);
    disp('=== Noise Case: P=0.05, G=0.025===');
    par.lambda = 0.2;
    par.tau  = 0.009;
    par.r =5;
    par.blocksize = 60;
    par.stepsize  = 20;
    par.maxIter = 20;
    par.tol = 1e-8;  
    tic; 
    [Re_msi{i}]= TLR_L1_2SSTV(noisy_msi,par);
    Time(i) = toc;
    Re_msi{i}(Re_msi{i}>1)=1;
    Re_msi{i}(Re_msi{i}<0)=0;   
    [psnr(i), ssim(i), fsim(i)] = MSIQA(Omsi * 255, Re_msi{i}  * 255);
    disp([methodname{i}, ' done in ' num2str(Time(i)), ' s.'])
    disp([methodname{i}, ' PSNR ' num2str(psnr(i)), ' .'])
    disp('...')
%     if getGif; togetGif(Re_msi{i},[saveroad, '/GIF/', methodname{i}]); end
%     if getImage; imwrite((Re_msi{i}(:,:,band)-minI)/(maxI-minI),[saveroad,'/Image/', methodname{i}, '.png']);end
    enList = [enList,i];
end
%% Show result
fprintf('\n');
fprintf('================== Result =====================\n');
fprintf(' %8.8s    %5.4s    %5.4s    %5.4s    \n','method','PSNR', 'SSIM', 'FSIM');
for i = 1:length(enList)
    fprintf(' %8.8s    %5.3f    %5.3f    %5.3f     \n',...
        methodname{enList(i)},psnr(enList(i)), ssim(enList(i)), fsim(enList(i)));
end
fprintf('===Band images are displayed in the Figure window===\n');
close all;
showMSIResult(Re_msi,Omsi,minI,maxI,methodname,enList,band,p)
